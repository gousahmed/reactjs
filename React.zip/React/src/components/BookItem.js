// BookItem.js
import React from 'react';
import './book.css';

const BookItem = ({ book }) => {
  const { volumeInfo } = book;
  const { title, authors, imageLinks } = volumeInfo;

  return (
    <div className='book'>
      <img src={imageLinks ? imageLinks.thumbnail : ''} alt="Book Cover" />
      <h2>{title}</h2>
      <p> {authors ? authors.join(', ') : 'Unknown'}</p>
    </div>
  );
};

export default BookItem;


