import React, { useState, useEffect } from 'react';
import BookList from './components/BookList';
import SearchBar from './components/SearchBar'; // Import the SearchBar component

const App = () => {
  const [books, setBooks] = useState([]);
  const [query, setQuery] = useState('Harry Potter'); // Default search query

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await fetch(`https://www.googleapis.com/books/v1/volumes?q=${query}`);
        if (!response.ok) {
          throw new Error('Failed to fetch data');
        }
        const data = await response.json();
        setBooks(data.items);
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    };

    fetchBooks();
  }, [query]);

  const handleSearch = (newQuery) => {
    setQuery(newQuery);
  };

  return (
    <div>
      {/* Include the SearchBar component */}
      <SearchBar onSearch={handleSearch} />
      <hr/>
      <BookList books={books} />
    </div>
  );
};

export default App;


